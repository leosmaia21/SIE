#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/attribs.h>
#include <xc.h>
#include "adc.h"
#include "uart.h"
#include "PWM.h"
#include "config_bits.h"
#include "timer2.h"
#include "timer3.h"

#define SYSCLK 80000000L  // System clock frequency, in Hz
#define PBCLOCK 40000000L // Peripheral Bus Clock frequency, in Hz

volatile int count = 0;
volatile char direction = 0;
int main(int argc, char **argv)
{

  TRISEbits.TRISE7 = 0;
  // Init UART and redirect tdin/stdot/stderr to UART
  if (UartInit(PBCLOCK, 115200) != UART_SUCCESS)
  {
    PORTAbits.RA3 = 0; // If Led active error initializing UART
    while (1)
      ;
  }
  AdcConfig();
  __XC_UART = 1; /* Redirect stdin/stdout/stderr to UART1*/

  INTCONSET = _INTCON_MVEC_MASK;
  __builtin_enable_interrupts();

  Timer2Config(20000);
  PWMInit();

  TRISEbits.TRISE8 = 1; // Set pin as input
  TRISDbits.TRISD2 = 1; // D2 as digital input

  /* Configuração interrupcao UART */
  INTCONbits.INT1EP = 1; // Generate interrupts on {rising edge-1 falling edge - 0}
  IFS0bits.INT1IF = 0;   // Reset int flag
  IPC1bits.INT1IP = 5;   // Set interrupt priority (1..7) *** Set equal to ilpx above
  IEC0bits.INT1IE = 1;   // Enable Int1 interrupts
  while (1)
  {
  }
}
void __ISR(24) isr_uart1(void)
{
  IFS0bits.U1RXIF = 0;
}

void __ISR(_EXTERNAL_1_VECTOR, IPL5AUTO) ExtInt1ISR(void)
{
printf("teste");
  if (PORTDbits.RD2 == 1)
  {
    count = count + 1; // Increments counter
    // direction = 1;
  }
  else
  {
    count = count - 1; // Decrements counter
    // direction = -1;
  }

  IFS0bits.INT1IF = 0; // Reset interrupt flag
}
void __ISR(_TIMER_2_VECTOR, IPL4AUTO) T2Interrupt(void)
{
  IFS0bits.T2IF = 0;
}
void __ISR(_TIMER_3_VECTOR, IPL4AUTO) T3Interrupt(void)
{
  IFS0bits.T4IF = 0;
}